from django.apps import AppConfig


class LoginNRegistrationAppConfig(AppConfig):
    name = 'login_n_registration_app'
