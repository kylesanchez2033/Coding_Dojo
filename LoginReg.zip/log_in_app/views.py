from django.shortcuts import redirect, render
from .models import Shirt, User
from django.shortcuts import render, redirect


def index(request):
    return render(request, 'index.html')


# from .models import *


# Create your views here.
def index(request):
    return render(request, "index.html")


def register(request):
    print(request.POST)
    # TODO
    # code some stuff to register a user in DB
    # ClassName.objects.create(field1="value for field1", field2="value for field2", etc.)

    # before we create a user check for uniqueness
    # check the db for the username
    user_in_db = User.objects.filter(username=request.POST["username"])

    if len(user_in_db) > 0:
        print("user exists")
        return redirect("/")
    else:
        new_user = User.objects.create(
            username=request.POST["username"],
            email=request.POST["email"],
            dob=request.POST["dob"],
            password=request.POST["password"],
        )
        # add newly created user to session
        request.session['email'] = new_user.email
        return redirect("/dashboard")


def login(request):
    # TODO
    # code some stuff to register a user in DB
    # check user in db
    userList = User.objects.filter(email=request.POST["email"])
    print(userList)
    if len(userList) == 1:
        print('we found the user')
        # set the user in session
        request.session['email'] = userList[0].email
        return redirect("/dashboard")
    else:
        print('no user with that email')
        return redirect('/')


def logout(request):
    request.session.clear()
    return redirect('/')


def dashboard(request):
    # check session if we have an email
    if request.session.get('email') == None:
        return redirect('/')
    # else redirect them to '/'

    # Create a user in the shell
    # python manage.py shell
    # don't forget to import your models

    # User.objects.create(
    #     username="Alex", email="a@alex.com", dob="1/1/2020", password="not very secure"
    # )

    # TODO
    # load all the users from the DB
    context = {
        "shirtz": Shirt.objects.all(),
        'user': User.objects.get(email=request.session['email']),
        'products': ['stuff', 'otherStuff']
    }
    return render(request, "dashboard.html", context)


def create_shirt(request):
    print(request.POST)
    # get the current user
    current_user = User.objects.get(email=request.session['email'])
    print('current_user: ', current_user)
    print('creating a shirt')
    Shirt.objects.create(
        size=request.POST['size'],
        design=request.POST['design'],
        uploaded_by=current_user
    )
    return redirect('/dashboard')
