from django.db import models


# Create your models here.
class User(models.Model):
    username = models.CharField(max_length=15)
    email = models.CharField(max_length=30)
    dob = models.CharField(max_length=15)
    password = models.CharField(max_length=30)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # uploaded_shirts

    # objects


class Shirt(models.Model):
    size = models.CharField(max_length=15, blank=False, default='Large')
    design = models.CharField(max_length=15)
    quantity = models.IntegerField(default=0)
    # one to many
    uploaded_by = models.ForeignKey(
        'User',
        related_name='uploaded_shirts',
        on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
