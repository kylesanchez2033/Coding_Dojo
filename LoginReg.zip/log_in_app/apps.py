from django.apps import AppConfig


class LogInAppConfig(AppConfig):
    name = 'log_in_app'
