from django.apps import AppConfig


class WordGeneratorAppConfig(AppConfig):
    name = 'word_generator_app'
