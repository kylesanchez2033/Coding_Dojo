# from django.shortcuts import render

# # Create your views here.

from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string
# Create your views here.


def index(request):
    request.session['counter'] = 0
    return HttpResponse("word_generator_app.")


def word_generator_app(request):
    request.session['counter'] += 1
    ran_wd = get_random_string(length=14)
    context = {'word_generator_app': ran_wd}
    return render(request, 'word_generator_app.html', context)


def reset(request):
    request.session['counter'] = 0
    return redirect('/word_generator_app')