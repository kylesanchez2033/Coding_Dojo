from django.urls import path
from . import views

# NO LEADING SLASHES
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('word_generator_app', views.word_generator_app),
    path('word_generator_app/reset', views.reset)
]